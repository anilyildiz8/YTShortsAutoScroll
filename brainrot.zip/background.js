chrome.runtime.onInstalled.addListener(() => {
  console.log("YT Shorts AutoScroll extension installed.");
});